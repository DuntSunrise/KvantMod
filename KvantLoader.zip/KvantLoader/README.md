# Kvant Loader

Android-приложение (Kotlin) с экраном активации по лицензионному ключу.

## Как работает

1. При первом запуске показывается экран ввода ключа.
2. Если ключ совпадает с `Kvant-Mvp-Ms829alKWSBkwsb7619`, активация сохраняется в `SharedPreferences`, и дальше приложение сразу открывает главный экран.
3. Ключ сейчас захардкожен в `KeyActivity.kt` (см. `VALID_KEY`) — это MVP-уровень. Для реального продукта ключ должен проверяться на сервере, а не лежать в коде APK (его легко достать декомпиляцией).

## Сборка локально (Android Studio)

1. Открыть папку проекта в Android Studio.
2. Дать Gradle досинхронизироваться (сам скачает wrapper).
3. Run ▶ на эмуляторе/устройстве, либо Build → Build APK(s).

## Сборка через GitHub

В репозитории уже лежит `.github/workflows/build.yml`:

1. Запушить проект в свой репозиторий на GitHub.
2. Workflow запустится автоматически на пуш в `main` (или вручную через вкладку Actions → Run workflow).
3. Готовый `app-debug.apk` появится в разделе **Actions → (запуск) → Artifacts**.

Примечание: в этом скаффолде нет бинарного `gradle-wrapper.jar` (не было сети, чтобы его скачать), поэтому workflow ставит Gradle 8.5 напрямую через `gradle/actions/setup-gradle`. Если хотите собирать локально через `./gradlew`, в Android Studio: File → выполнить `gradle wrapper`, чтобы он сам досоздал `gradle/wrapper/gradle-wrapper.jar`.

## Структура

```
app/src/main/java/com/kvant/loader/
  KeyActivity.kt   — экран ввода ключа
  MainActivity.kt  — главный экран после активации
app/src/main/res/layout/
  activity_key.xml
  activity_main.xml
```

## Дальше можно добавить

- Проверку ключа через API вместо хардкода.
- Разные ключи/тарифы, срок действия ключа.
- Реальный функционал приложения после активации (сейчас — просто заглушка-экран).
